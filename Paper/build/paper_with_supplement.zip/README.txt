main.pdf is the current revised manuscript, including the clearer matched optimization headline and qualified balanced-flow diagnostic.
archival_full_version.pdf is the earlier supporting manuscript cited by main.pdf. Keep both PDFs together for relative links.
